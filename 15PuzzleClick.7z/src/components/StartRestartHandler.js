import data from './Data';

const startRestartHandler = (state, action) => {
	let newTiles = [...data];
		/*for (let i = newTiles.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			let temp = newTiles[i];
			newTiles[i] = newTiles[j];
			newTiles[j] = temp;
		}*/
	return {cells: newTiles, moves: 0, startRestart: 'Restart', isWon: false, resetTime: true, spentTime: null, running: false};
}

export default startRestartHandler