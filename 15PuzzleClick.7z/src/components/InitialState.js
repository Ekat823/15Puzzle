import data from './Data';

const initialState = {
	cells: data,
	moves: 0,
	startRestart: 'Start',
	isWon: false,	
	spentTime: null,
	resetTime: false,
	running: false,
};
		
export default initialState