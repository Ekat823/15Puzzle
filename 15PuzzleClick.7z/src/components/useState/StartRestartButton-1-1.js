import React from 'react';

const StartRestartButton = ({cells, changeCells, startRestart, changeStartRestart, changeMoves, changeIsWon, changeRunning, changeTime}) => {
	
	const handleClickRestart = () => {
		let tiles = [...cells];
		for (let i = tiles.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			let temp = tiles[i];
			tiles[i] = tiles[j];
			tiles[j] = temp;
		}
		changeCells(tiles);
		changeStartRestart('Restart');
		changeMoves(0);
		changeIsWon(false);
		changeRunning(false);
		changeTime(0);
	};

	return <button 
					className='btn' 
					onClick={handleClickRestart}
				>
				{startRestart === 'Start' ? 'Start' : startRestart === 'Restart' ? 'Restart' : 'Play Again' }
				</button>
}

export default StartRestartButton