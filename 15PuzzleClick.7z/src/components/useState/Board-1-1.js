import React, { useState } from 'react';
import data from './data';
import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';

const Board = () => {

	let mappingData = data.map((el) => {
		return <img src={el.src} 
					id={el.id} 
					alt={el.alt} 
					key={el.id}/>;
		});
	
	let Tiles = [...mappingData, ' '];

	const [cells, setCells] = useState(Tiles);
	const [moves, setMoves] = useState(0);
	
	const [time, setTime] = useState(0);
	const [running, setRunning] = useState(false);

	const [startRestart, setStartRestart] = useState('Start')
	
	const [isWon, setIsWon] = useState(false);
	
	if(!isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
					cells={cells}
					changeCells={cells => setCells(cells)}
					startRestart={startRestart}
					changeStartRestart={startRestart => setStartRestart(startRestart)}
					changeMoves={moves=> setMoves(moves)}
					changeIsWon={isWon => setIsWon(isWon)}
					changeRunning={running => setRunning(running)}
					changeTime={time => setTime(time)}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {moves}
							</td>
							<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>
						</tr>
					</tbody>
				</table>
				<table  className='style1'>
					<tbody>
						<Table 
							cells={cells}
							changeCells={cells => setCells(cells)}
							startRestart={startRestart}
							changeStartRestart={startRestart => setStartRestart(startRestart)}
							moves={moves}
							changeMoves={moves=> setMoves(moves)}
							idWon={isWon}
							changeIsWon={isWon => setIsWon(isWon)}
							changeRunning={running => setRunning(running)}
							changeTime={time => setTime(time)}
						/>
					</tbody>
				</table>
			</div>
		);
	}
	
//--------------------Won Render	

	if(isWon) {
		return (
			<div className='container-won'>
				<h3 className='won'>You Won!</h3>
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Moves:  {moves}
							</td>
							<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>
						</tr>
					</tbody>
				</table>			
				<p>
					<StartRestartButton 
					cells={cells}
					changeCells={cells => setCells(cells)}
					startRestart={startRestart}
					changeStartRestart={startRestart => setStartRestart(startRestart)}
					changeMoves={moves=> setMoves(moves)}
					changeIsWon={isWon => setIsWon(isWon)}
					changeRunning={running => setRunning(running)}
					changeTime={time => setTime(time)}
				/>
				</p>
			</div>
		);
	}
}

export default Board