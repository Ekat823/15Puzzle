import React, { useState, useEffect } from 'react';

const Stopwatch = ({time, setTime, running}) => {	

	useEffect(() => {
		let interval;
		if(running) {
		interval = setInterval(() => {
			setTime((prevTime) => prevTime + 100);
		}, 100);
		} else if (!running) {
			clearInterval(interval);
		}
		return () => clearInterval(interval);
	}, [running]);
  
	let hours = (("0" + Math.floor((time / 3600000) % 60)).slice(-2));
	
	let min = (("0" + Math.floor((time / 60000) % 60)).slice(-2));
	
	let sec = (("0" + Math.floor((time / 1000) % 60)).slice(-2));
 
	return <div>Time: {hours}:{min}:{sec}</div>
}
	
export default Stopwatch