import React from 'react';

const Table = ({cells, handleClick}) => {
	
	const tableWidth = 4;
	const tableHeight = 4;
	
	const renderTable = (rows, columns) => {
		let result = [];
		for(let i = 0; i < rows; i++) {
			let c = [];
			for(let j = 0; j < columns; j++) {
				c.push(
					<td  
						className='style1' 
						key={(i * columns + j)} 
						onClick={() => handleClick(i * columns + j)}
					>
						{cells[(i * columns + j)]}
					</td>
				);
			}
			result.push(
				<tr key={i}>
					{c}
				</tr>
			);
		}
		return result;
	};
	
	return <>{renderTable(tableWidth, tableHeight)}</>
}

export default Table