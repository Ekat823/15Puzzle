import React from 'react';

const StartRestartButton = ({handleClickRestart, startRestart}) => {
	return <button 
					className='btn' 
					onClick={handleClickRestart}
				>
				{startRestart === 'Start' ? 'Start' : startRestart === 'Restart' ? 'Restart' : 'Play Again' }
				</button>
}

export default StartRestartButton