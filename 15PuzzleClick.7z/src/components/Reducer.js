import tableMoveTiles from './TableMoveTiles';
import startRestarthandler from './StartRestartHandler';

const reducer = (state, action) => {
	switch (action.type) {
		case 'restart':
			return startRestarthandler(state, action);
		case 'move':
			return tableMoveTiles(state, action);
		case 'disableResetTime':
			return {...state, resetTime: false};
		case 'setSpentTime':
			return {...state, spentTime: action.spentTime};
		default:
			return state
	}
};

export default reducer