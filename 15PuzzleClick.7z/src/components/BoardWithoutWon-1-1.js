import React, { useReducer } from 'react';
import initialState from './InitialState';
import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';
import Won from './Won'
import reducer from './Reducer'

const Board = () => {
	
	const [state, dispatch] = useReducer(reducer, initialState)
	
	if(!state.isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
					startRestart={state.startRestart}
					handleClickRestart={() => dispatch({type: 'restart'})}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {state.moves}
							</td>
							{<td>
							<Stopwatch  
								resetTime={state.resetTime}
								running={state.running}/>
							</td>}
						</tr>
					</tbody>
				</table>				
				<Table 
					cells={state.cells}
					handleClick={(num) => () => dispatch({type: 'move', num})}
				/>
			</div>
		);
	}
	
//--------------------Won Render	

	if(state.isWon) {
		return <Won moves={state.moves} resetTime={state.resetTime} running={state.running} startRestart={state.startRestart} handleClickRestart={() => dispatch({type: 'restart'})} />
	}
}

export default Board