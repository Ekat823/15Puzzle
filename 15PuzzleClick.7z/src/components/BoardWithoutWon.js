import React, { useReducer } from 'react';
import initialState from './InitialState';
import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';
import Won from './Won'
import reducer from './Reducer'

const Board = () => {
	
	const [state, dispatch] = useReducer(reducer, initialState)
	
	if(!state.isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
					startRestart={state.startRestart}
					handleClickRestart={() => dispatch({type: 'restart'})}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {state.moves}
							</td>
							<td>
							<Stopwatch 
								resetTime={state.resetTime}
								running={state.running}
								disableResetTime={() => dispatch({type: 'disableResetTime'})}
								setSpentTime={(time) => dispatch({type: 'setSpentTime', spentTime: time})}
							/>
							</td>
						</tr>
					</tbody>
				</table>				
				<Table 
					cells={state.cells}
					handleClick={(num) => () => dispatch({type: 'move', num})}
				/>
			</div>
		);
	}
	
//--------------------Won Render	

	if(state.isWon) {
		return 	<Won 
			spentTime={state.spentTime}
			moves={state.moves}
			handleClickRestart={() => dispatch({type: 'restart'})} 
		/>
	}
}

export default Board