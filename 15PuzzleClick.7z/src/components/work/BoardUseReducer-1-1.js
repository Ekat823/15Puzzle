import React, { useState, useReducer } from 'react';
import data from './data';
//import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';

	/*const swap = (arr, val1, val2) => {
		let squares = [...arr];
		[squares[val2], squares[val2 + val1]] = [squares[val2 + val1], squares[val2]];
		return squares;
	};	*/

const reducer = (state, action) => {
		switch (action.type) {
			case 'restart':
				return {
					cells: state.cells.sort(() => 0.5 - Math.random()), 
					moves: 0, 
					startRestart: 'Restart', 
					isWon: false
				}
			case 'move':
				return {
					...state, 
					cells: this.squares(state.cells, action.value1, action.value2),
					squares: (arr, value1, value2) => {			
						[arr[value2], arr[value2 + value1]] = [arr[value2 + value1], arr[value2]]
						return arr
					},										
					moves: state.moves + 1
				}
			case 'won': 
				return {
					...state, 
					startRestart: 'Play Again', 
					isWon: true
				}
			default:
				return state
		}
	}


const Board = () => {

	let mappingData = data.map((el) => {
		return <img src={el.src} 
					id={el.id} 
					alt={el.alt} 
					key={el.id}/>;
		});
	
	let tiles = [...mappingData, ' '];

	const initialState = {
			cells: tiles,
			moves: 0,
			startRestart: 'Start',
			isWon: (false),
			
		}

	
	//const [time, setTime] = useState(0);
	//const [running, setRunning] = useState(false);
	
	
	
	const [state, dispatch] = useReducer(reducer, initialState)
console.log(state)
	

	/*const [cells, setCells] = useState(Tiles);
	const [moves, setMoves] = useState(0);
	const [startRestart, setStartRestart] = useState('Start')
	const [isWon, setIsWon] = useState(false);*/
	

	
	
	const handleClickRestart = () => {
		dispatch({type: 'restart'})
		//setRunning(false);
		//setTime(0)
	};
	
	
	const handleClick = (num) => {
		
		if(state.startRestart === 'Start') {
		return;
		}
		
		/*if(state.isWon === true) {
			setRunning(false);
			return;
		}*/

		/*if(state.moves === 0) {
			setRunning(true);
		}*/

		if(state.cells[num + 1] === ' ' && (num + 1) % 4 !== 0) {
		dispatch({type: 'move', value1: 1, value2: num});
		} 
		else if(state.cells[num + 4] === ' ' && num < 12) {
			dispatch({type: 'move', value1: 4, value2: num});
		}
		else if(state.cells[num - 1] === ' ' && num % 4 !==0) {
			dispatch({type: 'move', value1: -1, value2: num});
		}
		else if(state.cells[num - 4] === ' ' && num >= 4 ) {
			dispatch({type: 'move', value1: -4, value2: num});
		} else {
			return;
		}
		
		let testArr = state.cells.filter((el) => el !== ' ');
		let test = testArr.find((el) => Number(el.key) !== state.cells.indexOf(el) + 1);
//console.log(test);
		if(test === undefined) {
			dispatch({type: 'won'});
			//setRunning(false);
		}
	};
	
	
	
	if(!state.isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
					startRestart={state.startRestart}
					handleClickRestart={handleClickRestart}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {state.moves}
							</td>
							{/*<td>
							<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>*/}
						</tr>
					</tbody>
				</table>
				<table  className='style1'>
					<tbody>
						<Table 
							cells={state.cells}
							handleClick={handleClick}
						/>
					</tbody>
				</table>
			</div>
		);
	}
	
//--------------------Won Render	

	if(state.isWon) {
		return (
			<div className='container-won'>
				<h3 className='won'>You Won!</h3>
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Moves:  {state.moves}
							</td>
							{/*<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>*/}
						</tr>
					</tbody>
				</table>			
				<p>
					<StartRestartButton 
					startRestart={state.startRestart}
					handleClickRestart={handleClickRestart}
				/>
				</p>
			</div>
		);
	}
}

export default Board