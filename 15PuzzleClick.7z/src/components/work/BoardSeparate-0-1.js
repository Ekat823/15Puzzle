import React, { useState } from 'react';
import data from './data';
import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';

const Board = () => {

	let mappingData = data.map((el) => {
		return <img src={el.src} 
					id={el.id} 
					alt={el.alt} 
					key={el.id}/>;
		});
	
	let tiles = [...mappingData, ' '];

	const [cells, setCells] = useState(tiles);
	const [moves, setMoves] = useState(0);
	
	const [time, setTime] = useState(0);
	const [running, setRunning] = useState(false);

	const [startRestart, setStartRestart] = useState('Start')
	
	const [isWon, setIsWon] = useState(false);
	
	const handleClickRestart = () => {
		let newTiles = [...cells];
		for (let i = newTiles.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			let temp = newTiles[i];
			newTiles[i] = newTiles[j];
			newTiles[j] = temp;
		}
		setCells(newTiles);
		setStartRestart('Restart');
		setMoves(0);
		setIsWon(false);
		setRunning(false);
		setTime(0)
	};
	
	
	const handleClick = (num) => {
		
		if(startRestart === 'Start') {
		return;
		}
		
		if(isWon === true) {
			setRunning(false);
			return;
		}
		
		let squares = [...cells];
		let move = moves;
		
		if(move === 0) {
			setRunning(true);
		}

		if(squares[num + 1] === ' ' && (num + 1) % 4 !== 0) {
			[squares[num], squares[num + 1]] = [squares[num + 1], squares[num]];
			move = move + 1;
		} 
		else if(squares[num + 4] === ' ' && num < 12) {
			[squares[num], squares[num + 4]] = [squares[num + 4], squares[num]];
			move = move + 1;
		}
		else if(squares[num - 1] === ' ' && num % 4 !==0) {
			[squares[num], squares[num - 1]] = [squares[num - 1], squares[num]];
			move = move + 1;
		}
		else if(squares[num - 4] === ' ' && num >= 4 ) {
			[squares[num], squares[num - 4]] = [squares[num - 4], squares[num]];
			move = move + 1;

		} else {
			return;
		}
		setCells(squares);
		setMoves(move);	
		
		let testArr = cells.filter((el) => el !== ' ');
		let test = testArr.find((el) => Number(el.key) !== squares.indexOf(el) + 1);
//console.log(test);
		if(test === undefined) {
			setIsWon(true);
			setStartRestart('Play Again');
			setRunning(false);
		}
	};
	
	
	
	if(!isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
					startRestart={startRestart}
					handleClickRestart={handleClickRestart}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {moves}
							</td>
							<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>
						</tr>
					</tbody>
				</table>
				<table  className='style1'>
					<tbody>
						<Table 
							cells={cells}
							handleClick={handleClick}
						/>
					</tbody>
				</table>
			</div>
		);
	}
	
//--------------------Won Render	

	if(isWon) {
		return (
			<div className='container-won'>
				<h3 className='won'>You Won!</h3>
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Moves:  {moves}
							</td>
							<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>
						</tr>
					</tbody>
				</table>			
				<p>
					<StartRestartButton 
					startRestart={startRestart}
					handleClickRestart={handleClickRestart}
				/>
				</p>
			</div>
		);
	}
}

export default Board