import React, { useState, useEffect } from 'react';
import data from './data'; //Test
import Stopwatch from './Stopwatch';

const Board = () => {

//----------Export Data	

	let NumArr = data.map((el) => {
		return <img src={el.src} id={el.id} alt={el.alt} key={el.id}/>;
		});
		
 //--------------		
 
	const [cells, setCells] = useState(NumArr);
	const [moves, setMoves] = useState(0);
	
// -------------Variables For Stopwatch

	const [time, setTime] = useState(0);
	const [running, setRunning] = useState(false);
	
//-----------Handle Click for Start and Play Again	

	const handleClickStart = () => {
		for (let i = NumArr.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			let temp = NumArr[i];
			NumArr[i] = NumArr[j];
			NumArr[j] = temp;
		}
		NumArr.push(' ');
		setCells(NumArr);
		setInfo(restart);
		setMoves(0);
		setIsWon(false);
		setRunning(false);
		setTime(0)
	}
	
//-----------Handle Click for Restart

	const handleClickRestart = () => {
		for (let i = NumArr.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			let temp = NumArr[i];
			NumArr[i] = NumArr[j];
			NumArr[j] = temp;
		}
		setCells(NumArr);
		setInfo(restart);
		setMoves(0);
		setIsWon(false);
		setRunning(false);
		setTime(0);
	}
	
//---------------Variables for Start and Restart Buttons, Info, and isWon

	const start = <button className='btn' onClick={handleClickStart}>Start</button>
	const restart = <button className='btn' onClick={handleClickRestart}>Restart</button>
	const [info, setInfo] = useState(start)
	const [isWon, setIsWon] = useState(false);
	
//----------------Handle Click for Tiles

	const handleClick = (num) => {
		
		if(info === start) {
		return;
		}
		
		if(isWon === true) {
			setRunning(false);
			return;
		}
		
		let squares = [...cells];
		let move = moves;
		
		if(move === 0) {
			setRunning(true);
		}

		if(squares[num + 1] === ' ' && (num + 1) % 4 !== 0) {
			let a = squares[num] 
			squares[num] = squares[num + 1];
			squares[num + 1] = a;
			move = move + 1;
		} 
		else if(squares[num + 4] === ' ' && num < 12) {
			let a = squares[num] 
			squares[num] = squares[num + 4];
			squares[num + 4] = a;
			move = move + 1;
		}
		else if(squares[num - 1] === ' ' && num % 4 !==0) {
			let a = squares[num] 
			squares[num] = squares[num - 1];
			squares[num - 1] = a;
			move = move + 1;
		}
		else if(squares[num - 4 ] === ' ' && num >= 4 ) {
			let a = squares[num] 
			squares[num] = squares[num - 4];
			squares[num - 4] = a;
			move = move + 1;

		} else {
			return;
		}
		setCells(squares);
		setMoves(move);	
		
		let testArr = cells.filter((el) => el !== ' ');
		let test = testArr.find((el) => Number(el.key) !== squares.indexOf(el) + 1);
		console.log(test);
		if(test === undefined) {
			setIsWon(true);
			setInfo(start);
			setRunning(false);
		}
	};
	
//--------------Table

	const tableWidth = 4;
	const tableHeight = 4;

	const renderTable = (rows, columns) => {
		let result = [];
		for(let i = 0; i < rows; i++) {
			let c = [];
			for(let j = 0; j < columns; j++) {
				c.push(<td  className='style1' key={(i * columns + j)} onClick={() => handleClick(i * columns + j)}>{cells[(i * columns + j)]}</td>);
			}
			result.push(<tr key={i}>{c}</tr>);
		}
		return result;
	};
	
//----------Game Render	
	
	if(!isWon) {
		return (
			<div className='container'>
				<p>{info}</p>			
				<table className='style2'>
					<tbody>
						<tr>
							<td>Move:  {moves}</td>
							<td><Stopwatch className='stopwatch'time={time} setTime={setTime} running={running}/></td>
						</tr>
					</tbody>
				</table>
				<table  className='style1'>
					<tbody>
						{renderTable(tableWidth, tableHeight)}
					</tbody>
				</table>
			</div>
		);
	}
	
//--------------------Won Render	

	if(isWon) {
		return (
			<div className='container-won'>
				<h3 className='won'>You Won!</h3>
				<table className='style2'>
					<tbody>
						<tr>
							<td>Moves:  {moves}</td>
							<td><Stopwatch className='stopwatch'time={time} setTime={setTime} running={running}/></td>
						</tr>
					</tbody>
				</table>			
				<p>
					<button className='btn-again' onClick={handleClickStart}>Play Again</button>
				</p>
			</div>
		);
	}
}

export default Board