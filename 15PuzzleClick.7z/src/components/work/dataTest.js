const data = [
	{id: 1, src: './images/img1.png', alt: '1'},
	{id: 2, src: './images/img2.png', alt: '2'},
	{id: 3, src: './images/img3.png', alt: '3'},
	{id: 4, src: './images/img4.png', alt: '4'},
	{id: 5, src: './images/img5.png', alt: '5'},
	{id: 6, src: './images/img6.png', alt: '6'},
	{id: 7, src: './images/img7.png', alt: '7'},
	{id: 8, src: './images/img8.png', alt: '8'},
	{id: 13, src: './images/img13.png', alt: '13'},
	{id: 9, src: './images/img9.png', alt: '9'},
	{id: 10, src: './images/img10.png', alt: '10'},
	{id: 11, src: './images/img11.png', alt: '11'},
	{id: 14, src: './images/img14.png', alt: '14'},
	{id: 15, src: './images/img15.png', alt: '15'},
	{id: 12, src: './images/img12.png', alt: '12'},
];

//const data = ['./images/img1.jpg', './images/img2.jpg', './images/img3.jpg', './images/img4.jpg', './images/img5.jpg', './images/img6.jpg', './images/img7.jpg', './images/img8.jpg', './images/img9.jpg', './images/img10.jpg', './images/img11.jpg', './images/img12.jpg', './images/img13.jpg', './images/img14.jpg', './images/img15.jpg'];

export default data