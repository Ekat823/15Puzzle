import React, { useReducer } from 'react';
import initialState from './InitialState';
//import Stopwatch from './Stopwatch';
import StartRestartButton from './StartRestartButton';
import Table from './Table';
import reducer from './reducer'

const Board = () => {

	//const [time, setTime] = useState(0);
	//const [running, setRunning] = useState(false);
	
	const [state, dispatch] = useReducer(reducer, initialState)
	
	if(!state.isWon) {
		return (
			<div className='container'>				
				<StartRestartButton
				startRestart={state.startRestart}
					handleClickRestart={() => dispatch({type: 'restart'})}
				/>	
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Move: {state.moves}
							</td>
							{/*<td>
							<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>*/}
						</tr>
					</tbody>
				</table>				
				<Table 
					cells={state.cells}
					handleClick={(num) => () => dispatch({type: 'move', num})}
				/>
			</div>
		);
	}
	
//--------------------Won Render	

	if(state.isWon) {
		return (
			<div className='container-won'>
				<h3 className='won'>You Won!</h3>
				<table className='style2'>
					<tbody>
						<tr>
							<td>
								Moves:  {state.moves}
							</td>
							{/*<td>
								<Stopwatch 
									className='stopwatch' 
									time={time} 
									setTime={setTime} 
									running={running}/>
							</td>*/}
						</tr>
					</tbody>
				</table>			
				<p>
					<StartRestartButton
					handleClickRestart={() => dispatch({type: 'restart'})}
				/>
				</p>
			</div>
		);
	}
}

export default Board