import moveTiles from './moveTiles';

const reducer = (state, action) => {
	switch (action.type) {
		case 'restart':
			return {
				//cells: state.cells, 
				cells: state.cells.sort(() => 0.5 - Math.random()), 
				moves: 0, 
				startRestart: 'Restart', 
				isWon: false
			}
		case 'move':
			return moveTiles(state, action)
		/*case 'won': 
			return {
				...state, 
				startRestart: 'Play Again', 
				isWon: true
			}*/
		default:
			return state
	}
};

export default reducer