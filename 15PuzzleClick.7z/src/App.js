import React from 'react';
import Board from './components/BoardWithoutWon'; //WithoutWon


function App() {
	return (
			<div>
				<Board />
			</div>
	);
}

export default App